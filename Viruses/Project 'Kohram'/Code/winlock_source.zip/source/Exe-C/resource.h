//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinLockEXE.rc
//
#define IDAPPLY                         3
#define IDD_HIDE                        101
#define IDD_KEYS                        102
#define IDC_DESKTOP                     1000
#define IDC_STARTBUTTON                 1001
#define IDC_TASKBAR                     1002
#define IDC_CLOCK                       1003
#define IDC_KEYS                        1004
#define IDC_ALTTAB1                     1005
#define IDC_ALTTAB2                     1006
#define IDC_TASKSWITCH                  1007
#define IDC_APPHIDE                     1008
#define IDC_APPHIDE2                    1009
#define IDC_TASKMGR                     1010
#define IDC_CTRLALTDEL                  1011
#define IDC_DESKTHREAD                  1012
#define IDC_DESKPROCESS                 1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
