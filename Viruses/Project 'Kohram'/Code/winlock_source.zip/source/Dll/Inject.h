/************
 * Inject.h *
 ************/

#include <windows.h>

BOOL Inject();
BOOL Eject();

int InjectDll();
int EjectDll();

int InjectCode();
int EjectCode();


